@extends('admin.layouts.app')

@section('title', 'PayPhi payments')

@section('content')
    <div class="container mt-4">
        <h3 class="mb-3">PayPhi Payment</h3>

        @if($errors->any())
            <div class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <p class="mb-0">{{ $error }}</p>
                @endforeach
            </div>
        @endif

        <form action="{{ route('payphi.initiate') }}" method="POST" id="checkoutForm">
            @csrf

            <div class="mb-3">
                <label class="form-label">Amount (₹)</label>
                <input type="number" name="amount" id="amount" step="0.01" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="customer_email" id="customer_email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Mobile</label>
                <input type="text" name="customer_mobile" id="customer_mobile" class="form-control" required>
            </div>

            {{-- Hidden field for customer_id --}}
            <input type="hidden" name="customer_id" id="customer_id">

            <button type="submit" class="btn btn-primary">Pay Now</button>
        </form>
    </div>
@endsection

@push('scripts')
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Get URL parameters
            const params = new URLSearchParams(window.location.search);

            // Autofill fields if present in URL
            if (params.has('amount')) {
                document.getElementById('amount').value = params.get('amount');
            }
            if (params.has('customer_email')) {
                document.getElementById('customer_email').value = params.get('customer_email');
            }
            if (params.has('customer_mobile')) {
                document.getElementById('customer_mobile').value = params.get('customer_mobile');
            }
            if (params.has('customer_id')) {
                document.getElementById('customer_id').value = params.get('customer_id');
            }
        });
    </script>
@endpush